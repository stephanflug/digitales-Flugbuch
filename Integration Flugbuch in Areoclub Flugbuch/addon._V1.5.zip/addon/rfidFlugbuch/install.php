<?php
/**
 * install.php – Installations-/Status-Seite + Update-Funktion (nur AppGini Admin)
 *
 * Zielpfad: html/addon/rfidFlugbuch/install.php
 *
 * Features:
 * - Admin-only (AppGini Session)
 * - Übersichtliche Checks: config.php, DB-Verbindung, Tabelle/Spalten, Schreibrechte, ID-Schutz, Logfile
 * - Update: ZIP hochladen und receiver.php/debug.php/install.php im Ordner überschreiben
 */

// ---- Addon Meta ----
const RFID_FLUGBUCH_ADDON_DEV = 'Ebner Stephan';
const RFID_FLUGBUCH_ADDON_VERSION = '1.5';

header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set('Europe/Vienna');

// ---------- AppGini bootstrap (best effort) ----------
$CANDIDATES = [
    __DIR__ . '/../../lib.php',
    __DIR__ . '/../../incCommon.php',
    __DIR__ . '/../../admin/incCommon.php',
    __DIR__ . '/../lib.php',
    __DIR__ . '/../incCommon.php',
];

$booted = false;
foreach ($CANDIDATES as $p) {
    if (is_file($p)) {
        require_once $p;
        $booted = true;
        break;
    }
}

if (!$booted) {
    http_response_code(500);
    echo "<h2>Install</h2><p><b>Fehler:</b> AppGini bootstrap nicht gefunden. Passe die include-Pfade in install.php an.</p>";
    exit;
}

function is_appgini_admin(): bool {
    if (function_exists('getLoggedAdmin')) {
        $a = getLoggedAdmin();
        return !empty($a);
    }
    if (function_exists('getLoggedMemberID')) {
        $id = getLoggedMemberID();
        if (!$id) return false;
        if ($id === 'admin') return true;
    }
    if (isset($_SESSION) && (isset($_SESSION['memberID']) || isset($_SESSION['admin']))) {
        if (!empty($_SESSION['admin'])) return true;
        if (!empty($_SESSION['memberID']) && $_SESSION['memberID'] === 'admin') return true;
    }
    return false;
}

if (!is_appgini_admin()) {
    http_response_code(403);
    echo "<h2>403</h2><p>Nur für AppGini Admin.</p>";
    exit;
}

// config.php hart einbinden (Pfad ist fix: html/config.php)
$cfg = __DIR__ . '/../../config.php';
$cfgLoaded = false;
if (is_file($cfg)) {
    // NICHT require_once – damit Variablen sicher im globalen Scope landen
    require $cfg;
    $cfgLoaded = true;
}

// ---------- Helpers ----------
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function badge(bool $ok): string {
    return $ok ? '<span class="ok">OK</span>' : '<span class="bad">FEHLT</span>';
}
function warnBadge(bool $ok): string {
    return $ok ? '<span class="ok">OK</span>' : '<span class="warn">WARN</span>';
}

function receiver_log_path(): string {
    $p1 = '/opt/digitalflugbuch/data/system/receiver_appgini_debug.jsonl';
    if (is_dir(dirname($p1))) return $p1;
    return __DIR__ . '/system/receiver_appgini_debug.jsonl';
}

function ids_path(): string {
    $p1 = '/opt/digitalflugbuch/data/system/ids.json';
    if (is_dir(dirname($p1))) return $p1;
    return __DIR__ . '/ids.json';
}

function safe_json_load_simple(string $path) {
    if (!is_file($path)) return null;
    $raw = @file_get_contents($path);
    if ($raw === false) return null;
    $data = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) return null;
    return $data;
}

function addon_db_connect(): PDO {
    // dein config.php hat diese Variablen
    $host = $GLOBALS['dbServer'] ?? 'localhost';
    $port = $GLOBALS['dbPort'] ?? '3306';
    $user = $GLOBALS['dbUsername'] ?? '';
    $pass = $GLOBALS['dbPassword'] ?? '';
    $name = $GLOBALS['dbDatabase'] ?? '';

    if (!$name || !$user) {
        throw new RuntimeException('DB creds missing');
    }

    return new PDO("mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

function table_has_columns(PDO $pdo, string $table, array $columns): array {
    $missing = [];
    $st = $pdo->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :t");
    $st->execute([':t' => $table]);
    $have = array_map(fn($r) => $r['COLUMN_NAME'], $st->fetchAll());
    $haveSet = array_flip($have);
    foreach ($columns as $c) {
        if (!isset($haveSet[$c])) $missing[] = $c;
    }
    return $missing;
}

function tail_lines(string $file, int $n = 40): array {
    if (!is_file($file)) return [];
    $lines = @file($file, FILE_IGNORE_NEW_LINES);
    if (!is_array($lines)) return [];
    return array_slice($lines, -$n);
}

// ---------- Auto-Patch: hooks/header-extras.php (Navbar Links) ----------
function find_header_extras_path(): ?string {
    $candidates = [];

    // common absolute
    $candidates[] = '/var/www/html/hooks/header-extras.php';

    // walk up from addon dir (e.g. /var/www/html/addon/rfidFlugbuch)
    $dir = realpath(__DIR__);
    for ($i = 0; $i < 7 && $dir; $i++) {
        $candidates[] = $dir . '/hooks/header-extras.php';
        $candidates[] = $dir . '/html/hooks/header-extras.php';
        $parent = dirname($dir);
        if ($parent === $dir) break;
        $dir = $parent;
    }

    foreach ($candidates as $p) {
        if ($p && is_file($p)) return $p;
    }
    return null;
}

function header_extras_block(): string {
    // idempotent block between markers
    return "\n<!-- BEGIN RFIDFlugbuch Plugin Links -->\n" .
        "<script>\n" .
        "  (function () {\n" .
        "    if (typeof AppGiniHelper === 'undefined' || !AppGiniHelper.common) return;\n\n" .
        "    var navbar = AppGiniHelper.common.getNavbar();\n" .
        "    var baseUrl = window.location.origin;\n\n" .
        "    var dd = navbar.addDropdown(\"Plugin\", \"wrench\", NavPosition.Right);\n\n" .
        "    dd.addLink(\"Integration (Installationsseite)\", baseUrl + \"/addon/rfidFlugbuch/install.php\", \"cog\", \"_blank\");\n" .
        "    dd.addLink(\"RFIDFlugbuch\", \"https://github.com/stephanflug/digitales-Flugbuch\", \"github\", \"_blank\");\n" .
        "    dd.addLink(\"Flugbuch Website\", \"https://flugbuch.gltdienst.home64.de/\", \"globe\", \"_blank\");\n" .
        "    dd.addLink(\"Doku\", \"https://doko.flugbuch.gltdienst.home64.de/share/hiv8kxsvqf/p/hauptanleitung-wzmoqxhi8D\", \"book\", \"_blank\");\n" .
        "  })();\n" .
        "</script>\n" .
        "<!-- END RFIDFlugbuch Plugin Links -->\n";
}

function patch_header_extras_if_possible(?string $path): array {
    // returns [attempted(bool), ok(bool), message(string)]
    if (!$path) return [false, false, 'header-extras.php nicht gefunden'];
    if (!is_writable($path)) return [false, false, 'keine Schreibrechte'];

    $content = @file_get_contents($path);
    if ($content === false) return [true, false, 'konnte Datei nicht lesen'];

    $begin = '<!-- BEGIN RFIDFlugbuch Plugin Links -->';
    $end   = '<!-- END RFIDFlugbuch Plugin Links -->';
    $block = header_extras_block();

    if (strpos($content, $begin) !== false && strpos($content, $end) !== false) {
        // replace existing block
        $pattern = '/\\n?<!-- BEGIN RFIDFlugbuch Plugin Links -->.*?<!-- END RFIDFlugbuch Plugin Links -->\\n?/s';
        $newContent = preg_replace($pattern, $block, $content, 1);
        if ($newContent === null) return [true, false, 'regex replace fehlgeschlagen'];
    } else {
        // append
        $newContent = rtrim($content) . "\n" . $block;
    }

    // backup
    $bak = $path . '.bak-' . date('Ymd-His');
    @copy($path, $bak);

    $tmp = tempnam(dirname($path), 'hdr_');
    if ($tmp === false) return [true, false, 'tempnam fehlgeschlagen'];
    if (@file_put_contents($tmp, $newContent) === false) { @unlink($tmp); return [true, false, 'konnte temp nicht schreiben']; }
    if (!@rename($tmp, $path)) { @unlink($tmp); return [true, false, 'rename fehlgeschlagen']; }

    return [true, true, 'installiert/aktualisiert'];
}

// ---------- Checks ----------
$checks = [];

// Auto-patch header-extras (silent if no permissions)
$headerExtrasPath = find_header_extras_path();
[$hdrAttempted, $hdrOk, $hdrMsg] = patch_header_extras_if_possible($headerExtrasPath);
$checks['Navbar Links (header-extras.php)'] = [
    'ok' => $hdrOk || !$hdrAttempted, // if not attempted because no permission, don't fail the whole status
    'detail' => ($headerExtrasPath ? $headerExtrasPath : '(nicht gefunden)') . ' · ' . $hdrMsg,
];

$checks['config.php vorhanden'] = [
    'ok' => $cfgLoaded,
    'detail' => $cfg,
];

$systemDir = dirname(receiver_log_path());
$checks['Addon-Ordner beschreibbar (system/)'] = [
    'ok' => is_dir($systemDir) ? is_writable($systemDir) : is_writable(__DIR__),
    'detail' => is_dir($systemDir) ? $systemDir : __DIR__,
];

$idPath = ids_path();
$idData = safe_json_load_simple($idPath);
$storedId = is_array($idData) ? ($idData['ID'] ?? null) : null;
$checks['ID-Schutz (ids.json)'] = [
    'ok' => (bool)$storedId,
    'detail' => $idPath . ' · ' . ($storedId ? ('ID gesetzt') : 'noch nicht gesetzt (kommt beim 1. Request)'),
];

$dbOk = false;
$dbErr = '';
$tableOk = false;
$tableMissingCols = [];
try {
    $pdo = addon_db_connect();
    $dbOk = true;
    $requiredCols = ['datum','beginn','ende','pilot','anzahl_fluege','max_flughoehe','luftraumbeobachter_anwesend','erfasser','erfasst'];
    $tableMissingCols = table_has_columns($pdo, 'flugbuch_verein', $requiredCols);
    $tableOk = (count($tableMissingCols) === 0);
} catch (Throwable $e) {
    $dbErr = $e->getMessage();
}

$checks['DB Verbindung'] = [
    'ok' => $dbOk,
    'detail' => $dbOk ? 'OK' : $dbErr,
];
$checks['Tabelle flugbuch_verein + Pflichtspalten'] = [
    'ok' => ($dbOk && $tableOk),
    'detail' => ($dbOk ? ($tableOk ? 'OK' : ('Fehlende Spalten: ' . implode(', ', $tableMissingCols))) : 'DB nicht OK'),
];

$logPath = receiver_log_path();
$logTail = tail_lines($logPath, 30);
$checks['Receiver Log vorhanden'] = [
    'ok' => is_file($logPath),
    'detail' => $logPath,
];

// ---------- Update (ZIP Upload) ----------
$updateMsg = null;
$updateOk = null;

function extract_update_zip(string $zipPath, string $targetDir): array {
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('ZipArchive fehlt (PHP extension zip).');
    }

    $za = new ZipArchive();
    $res = $za->open($zipPath);
    if ($res !== true) throw new RuntimeException('ZIP konnte nicht geöffnet werden.');

    $allowed = ['receiver.php','install.php'];
    $written = [];

    for ($i=0; $i<$za->numFiles; $i++) {
        $name = $za->getNameIndex($i);
        if ($name === false) continue;

        // Nur Basisdateien, keine Pfade
        $base = basename($name);
        if ($base !== $name) continue;
        if (!in_array($base, $allowed, true)) continue;

        $data = $za->getFromIndex($i);
        if ($data === false) continue;

        // simple size cap
        if (strlen($data) > 1024*1024) throw new RuntimeException("Datei zu groß im ZIP: {$base}");

        $tmp = tempnam($targetDir, 'upd_');
        if ($tmp === false) throw new RuntimeException('Tempdatei Fehler.');
        file_put_contents($tmp, $data);

        $dst = rtrim($targetDir, '/').'/'.$base;
        if (!rename($tmp, $dst)) {
            @unlink($tmp);
            throw new RuntimeException("Konnte nicht schreiben: {$dst}");
        }

        $written[] = $base;
    }

    $za->close();
    if (!$written) throw new RuntimeException('ZIP enthält keine erlaubten Dateien (receiver.php/debug.php/install.php).');
    return $written;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    try {
        if (!isset($_FILES['zip']) || $_FILES['zip']['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Upload fehlgeschlagen.');
        }
        $written = extract_update_zip($_FILES['zip']['tmp_name'], __DIR__);
        $updateOk = true;
        $updateMsg = 'Update OK. Aktualisiert: ' . implode(', ', $written) . '. Seite neu laden.';
    } catch (Throwable $e) {
        $updateOk = false;
        $updateMsg = 'Update FEHLER: ' . $e->getMessage();
    }
}

$allOk = true;
foreach ($checks as $c) { if (!$c['ok']) { $allOk = false; break; } }

// ---------- Derived URLs for user ----------
function current_base_url(): string {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost');
    return $scheme . '://' . $host;
}
$baseUrl = current_base_url();
$apiUrl = $baseUrl . rtrim(dirname($_SERVER['REQUEST_URI'] ?? ''), '/') . '/receiver.php';
$installUrl = $baseUrl . rtrim(dirname($_SERVER['REQUEST_URI'] ?? ''), '/') . '/install.php';
?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>RFID Flugbuch – Integration</title>
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;margin:0;background:#0b1220;color:#e5e7eb;}
    .wrap{max-width:1100px;margin:0 auto;padding:16px;}
    .top{display:flex;gap:14px;align-items:center;flex-wrap:wrap;justify-content:space-between;}
    .topLeft{display:flex;gap:12px;align-items:center;flex-wrap:wrap;}
    .topRight{display:flex;gap:10px;align-items:center;}
    .logo{width:44px;height:44px;border-radius:12px;object-fit:cover;border:1px solid #233045;background:#0b1220;}
    .muted{color:#9ca3af;}
    .card{background:#111827;border:1px solid #233045;border-radius:14px;padding:14px;margin:12px 0;}
    .row{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;padding:10px 0;border-bottom:1px solid #1f2a3a;}
    .row:last-child{border-bottom:0;}
    .k{font-weight:700;}
    .v{color:#cbd5e1;max-width:65%;word-break:break-word;text-align:right;}
    .ok{color:#22c55e;font-weight:900;}
    .bad{color:#ef4444;font-weight:900;}
    .warn{color:#f59e0b;font-weight:900;}
    a{color:#93c5fd;text-decoration:none;}
    a:hover{text-decoration:underline;}
    code,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;}
    pre{white-space:pre-wrap;background:#0b1220;border:1px solid #233045;border-radius:12px;padding:12px;max-height:320px;overflow:auto;}
    .btn{background:#2563eb;border:0;color:white;padding:10px 12px;border-radius:10px;font-weight:700;cursor:pointer;}
    .btn:disabled{opacity:.5;cursor:not-allowed;}
    .pill{display:inline-block;padding:4px 10px;border-radius:999px;font-weight:800;background:#0b1220;border:1px solid #233045;}
    .iconLink{display:inline-flex;align-items:center;gap:8px;padding:8px 10px;border-radius:12px;background:#0b1220;border:1px solid #233045;color:#e5e7eb;}
    .icon{width:18px;height:18px;display:inline-block;}
    .footer{margin-top:18px;color:#9ca3af;font-size:13px;}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="top">
      <div class="topLeft">
        <img class="logo" src="https://raw.githubusercontent.com/stephanflug/digitales-Flugbuch/refs/heads/main/Logo/LOGO.jpg" alt="RFID Flugbuch Logo" />
        <h1 style="margin:0;font-size:20px;">RFID Flugbuch – Integration</h1>
        <span class="pill">Version <?=h(RFID_FLUGBUCH_ADDON_VERSION)?></span>
        <span class="pill">Admin only</span>
        <span class="muted"><?=h((new DateTime('now'))->format('Y-m-d H:i:s'))?> · TZ: <?=h(date_default_timezone_get())?></span>
      </div>
      <div class="topRight">
        <a class="iconLink" href="https://github.com/stephanflug/digitales-Flugbuch" target="_blank" rel="noreferrer">
          <svg class="icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .5a12 12 0 0 0-3.8 23.4c.6.1.8-.3.8-.6v-2.2c-3.3.7-4-1.4-4-1.4-.6-1.4-1.4-1.8-1.4-1.8-1.2-.8.1-.8.1-.8 1.3.1 2 .1 2.6 1.9 1.2 2 3.2 1.4 4 .9.1-.9.5-1.4.9-1.7-2.6-.3-5.3-1.3-5.3-5.9 0-1.3.5-2.4 1.2-3.3-.1-.3-.5-1.5.1-3.1 0 0 1-.3 3.3 1.2a11.5 11.5 0 0 1 6 0C18.6 5 19.6 5.3 19.6 5.3c.6 1.6.2 2.8.1 3.1.8.9 1.2 2 1.2 3.3 0 4.6-2.7 5.6-5.3 5.9.5.4 1 1.2 1 2.5v3.7c0 .3.2.7.8.6A12 12 0 0 0 12 .5z"/></svg>
          GitHub
        </a>
        <a class="iconLink" href="https://doko.flugbuch.gltdienst.home64.de/share/hiv8kxsvqf/p/hauptanleitung-wzmoqxhi8D" target="_blank" rel="noreferrer">
          <svg class="icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6 2h9l5 5v15a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm8 1v5h5"/><path d="M8 12h8v2H8v-2zm0 4h8v2H8v-2z"/></svg>
          Doku
        </a>
      </div>
    </div>

    <div class="card">
      <h2 style="margin:0 0 8px 0;font-size:15px;">Status</h2>
      <div>Gesamt: <?= $allOk ? '<span class="ok">OK</span>' : '<span class="bad">NICHT OK</span>' ?></div>
      <div class="muted">Wenn etwas rot ist: Details stehen rechts. Häufigste Ursachen sind fehlende DB-Verbindung oder fehlende Schreibrechte.</div>
    </div>

    <div class="card">
      <h2 style="margin:0 0 8px 0;font-size:15px;">API REST</h2>
      <div class="muted" style="margin-bottom:8px;">Diese URL im RFID Flugbuch als Ziel-URL eintragen.</div>
      <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
        <div style="min-width:90px;font-weight:800;">API Rest:</div>
        <input id="apiUrl" value="<?=h($apiUrl)?>" readonly
               style="flex:1;min-width:260px;background:#0b1220;border:1px solid #233045;color:#e5e7eb;border-radius:10px;padding:10px 12px;" />
        <button class="btn" type="button" onclick="copyApiUrl()">Kopieren</button>
      </div>
    </div>

    <div class="card">
      <h2 style="margin:0 0 8px 0;font-size:15px;">Checks</h2>
      <?php foreach($checks as $name => $c): ?>
        <div class="row">
          <div>
            <div class="k"><?=h($name)?> <?=badge((bool)$c['ok'])?></div>
          </div>
          <div class="v"><code><?=h($c['detail'] ?? '')?></code></div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="card">
      <h2 style="margin:0 0 8px 0;font-size:15px;">Update</h2>
      <div class="muted">ZIP hochladen (enthält <code>receiver.php</code> und <code>install.php</code>). Es werden nur diese Dateien überschrieben.</div>
      <?php if($updateMsg !== null): ?>
        <div style="margin:10px 0;"><?= $updateOk ? '<span class="ok">OK</span>' : '<span class="bad">FEHLER</span>' ?> <?=h($updateMsg)?></div>
      <?php endif; ?>
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="action" value="update" />
        <input type="file" name="zip" accept="application/zip" required />
        <button class="btn" type="submit">ZIP hochladen & updaten</button>
      </form>
    </div>

    <div class="card">
      <h2 style="margin:0 0 8px 0;font-size:15px;">Letzte Receiver Events (tail)</h2>
      <?php if(!$logTail): ?>
        <div class="muted">Noch kein Log vorhanden. (Receiver muss aufgerufen werden.)</div>
      <?php else: ?>
        <pre><?=h(implode("\n", $logTail))?></pre>
      <?php endif; ?>
    </div>

    <div class="footer">Powered by <?=h(RFID_FLUGBUCH_ADDON_DEV)?> · Version <?=h(RFID_FLUGBUCH_ADDON_VERSION)?></div>
  </div>

  <script>
    function copyApiUrl(){
      var el = document.getElementById('apiUrl');
      if(!el) return;
      el.select();
      el.setSelectionRange(0, 99999);
      try {
        navigator.clipboard.writeText(el.value);
      } catch (e) {
        document.execCommand('copy');
      }
    }
  </script>
</body>
</html>
