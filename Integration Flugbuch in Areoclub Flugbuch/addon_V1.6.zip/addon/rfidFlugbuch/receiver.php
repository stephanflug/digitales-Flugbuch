<?php
/**
 * Abgedeckte Funktionen:
 * - JSON-Import mit ID + data[]
 * - ID-Initialisierung / ID-Prüfung über ids.json
 * - Nur Einträge vom heutigen Tag importieren
 * - Dedupe über datum + beginn + pilot
 * - Robuste Feldzuordnung (auch bei leicht abweichenden/codierten JSON-Keys)
 * - Optionales Member-Matching über membership_users.custom1
 * - Optionales Setzen des Record-Owners in membership_userrecords
 * - Kompatibel mit beiden bekannten Spaltennamen:
 *   - luftraumbeobachter_anwesend
 *   - luftraumbeobachter
 * receiver.php – RFID Flugbuch → AppGini (flugbuch_verein)
 *
 * Erwartete Payload: Objekt mit ID + Datenarray, z.B.
 * {
 *   "ID": "DEINE-DEVICE-ID",
 *   "data": [
 *     {
 *       "name": "Max Mustermann",
 *       "rfid": "660953104538",
 *       "startzeit": "2024-12-12 12:26:27",
 *       "endzeit": "2024-12-12 12:26:34",
 *       "Fluganzahl": "4",
 *       "Flughöhe": "120m",
 *       "Luftraumbeobachter": "Ja"
 *     }
 *   ]
 * }
 *
 * Logik:
 * - Nur Einträge vom HEUTIGEN Tag werden in AppGini geschrieben.
 * - Dedupe: datum + beginn + pilot
 * - DB Zugangsdaten werden aus ../../config.php geladen (AppGini).
 */


const RFID_FLUGBUCH_ADDON_DEV = 'Ebner Stephan';
const RFID_FLUGBUCH_ADDON_VERSION = '1.6';
const DEFAULT_ERFASSER = 'RFID Flugbuch';
const DEFAULT_GROUP_ID = '5';

header('Content-Type: application/json; charset=utf-8');
header('X-Addon-Developer: ' . RFID_FLUGBUCH_ADDON_DEV);
header('X-Addon-Version: ' . RFID_FLUGBUCH_ADDON_VERSION);
date_default_timezone_set('Europe/Vienna');

require __DIR__ . '/../../config.php';

function cfg_get(array $keys, $default = null) {
    foreach ($keys as $k) {
        if (array_key_exists($k, $GLOBALS) && $GLOBALS[$k] !== null && $GLOBALS[$k] !== '') {
            return $GLOBALS[$k];
        }
    }

    if (isset($GLOBALS['config']) && is_array($GLOBALS['config'])) {
        foreach ($keys as $k) {
            if (array_key_exists($k, $GLOBALS['config']) && $GLOBALS['config'][$k] !== null && $GLOBALS['config'][$k] !== '') {
                return $GLOBALS['config'][$k];
            }
        }
    }

    foreach ($keys as $k) {
        if (defined($k)) {
            $v = constant($k);
            if ($v !== null && $v !== '') {
                return $v;
            }
        }
    }

    return $default;
}

function build_pdo_from_config(): PDO {
    $host = cfg_get(['dbServer', 'dbHost', 'DB_HOST', 'mysql_host', 'APP_DB_HOST', 'HOST', 'HOSTNAME'], 'localhost');
    $user = cfg_get(['dbUsername', 'dbUser', 'DB_USER', 'mysql_user', 'APP_DB_USER', 'USER', 'USERNAME'], '');
    $pass = cfg_get(['dbPassword', 'dbPass', 'DB_PASS', 'mysql_password', 'APP_DB_PASS', 'PASS', 'PASSWORD'], '');
    $name = cfg_get(['dbDatabase', 'dbName', 'DB_NAME', 'mysql_db', 'APP_DB_NAME', 'DATABASE', 'DB_DATABASE'], '');

    if (is_array($host) || is_array($user) || is_array($name)) {
        throw new RuntimeException('DB Config Werte haben falschen Typ (Array) – config.php Struktur prüfen.');
    }

    if (!$name || !$user) {
        throw new RuntimeException('DB creds missing');
    }

    $dsn = "mysql:host={$host};dbname={$name};charset=utf8mb4";
    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

function dt_parts(string $s): array {
    $dt = new DateTime($s);
    return [
        'datum' => $dt->format('Y-m-d'),
        'time'  => $dt->format('H:i:s'),
    ];
}

function ids_path(): string {
    $p1 = '/opt/digitalflugbuch/data/system/ids.json';
    if (is_dir(dirname($p1))) {
        return $p1;
    }
    return __DIR__ . '/ids.json';
}

function safe_json_load(string $path, int $retries = 5, int $sleepMs = 50): array {
    if (!file_exists($path)) {
        return [];
    }

    for ($i = 0; $i < $retries; $i++) {
        $fp = @fopen($path, 'r');
        if ($fp === false) {
            usleep($sleepMs * 1000);
            continue;
        }

        @flock($fp, LOCK_SH);
        clearstatcache(true, $path);
        $size = filesize($path);
        $raw = $size > 0 ? fread($fp, $size) : '';
        @flock($fp, LOCK_UN);
        fclose($fp);

        if ($raw === '' || $raw === false) {
            return [];
        }

        $data = json_decode($raw, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($data)) {
            return $data;
        }

        usleep($sleepMs * 1000);
    }

    throw new RuntimeException("Konnte '$path' nicht stabil als JSON lesen: " . json_last_error_msg());
}

function safe_json_save(string $path, $data): void {
    $dir = dirname($path);
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        throw new RuntimeException("Verzeichnis '$dir' konnte nicht erstellt werden.");
    }

    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        throw new RuntimeException('JSON-Encoding fehlgeschlagen: ' . json_last_error_msg());
    }

    $tmp = tempnam($dir, 'tmp_');
    if ($tmp === false) {
        throw new RuntimeException("Tempdatei in '$dir' konnte nicht erstellt werden.");
    }

    $fp = fopen($tmp, 'c');
    if ($fp === false) {
        @unlink($tmp);
        throw new RuntimeException("Tempdatei '$tmp' konnte nicht geöffnet werden.");
    }

    if (!flock($fp, LOCK_EX)) {
        fclose($fp);
        @unlink($tmp);
        throw new RuntimeException("Konnte Lock für '$tmp' nicht erhalten.");
    }

    if (fwrite($fp, $json) === false) {
        flock($fp, LOCK_UN);
        fclose($fp);
        @unlink($tmp);
        throw new RuntimeException("Fehler beim Schreiben nach '$tmp'.");
    }

    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    if (!rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException("Konnte '$path' nicht ersetzen.");
    }
}

function enforce_id_or_init(string $incomingId): void {
    $path = ids_path();

    if (!file_exists($path)) {
        safe_json_save($path, ['ID' => $incomingId]);
        return;
    }

    $idData = safe_json_load($path);
    if (!isset($idData['ID']) || $idData['ID'] !== $incomingId) {
        http_response_code(403);
        echo json_encode([
            'status' => 'error',
            'message' => 'Die angegebene ID stimmt nicht mit der gespeicherten ID überein.',
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

function receiver_log_path(): string {
    $p1 = '/opt/digitalflugbuch/data/system/receiver_appgini_debug.jsonl';
    if (is_dir(dirname($p1))) {
        return $p1;
    }
    return __DIR__ . '/system/receiver_appgini_debug.jsonl';
}

function log_event(string $type, array $payload): void {
    $line = json_encode([
        'ts' => date('c'),
        'type' => $type,
        'payload' => $payload,
    ], JSON_UNESCAPED_UNICODE);

    if ($line === false) {
        return;
    }

    $file = receiver_log_path();
    @mkdir(dirname($file), 0755, true);
    @file_put_contents($file, $line . PHP_EOL, FILE_APPEND);
}

function normalize_key(string $key): string {
    $key = trim($key);
    $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $key);
    if ($ascii !== false && $ascii !== '') {
        $key = $ascii;
    }
    $key = mb_strtolower($key, 'UTF-8');
    return preg_replace('/[^a-z0-9]+/u', '', $key) ?? '';
}

function entry_value(array $entry, array $aliases, $default = null) {
    foreach ($aliases as $alias) {
        if (array_key_exists($alias, $entry)) {
            return $entry[$alias];
        }
    }

    $normalizedMap = [];
    foreach ($entry as $key => $value) {
        if (!is_string($key)) {
            continue;
        }
        $normalizedMap[normalize_key($key)] = $value;
    }

    foreach ($aliases as $alias) {
        $n = normalize_key($alias);
        if ($n !== '' && array_key_exists($n, $normalizedMap)) {
            return $normalizedMap[$n];
        }
    }

    return $default;
}

function parse_int_mixed($v, ?int $default = null): ?int {
    if ($v === null) {
        return $default;
    }
    if (is_int($v)) {
        return $v;
    }

    $s = trim((string) $v);
    if ($s === '') {
        return $default;
    }

    if (preg_match('/-?\d+/', $s, $m)) {
        return (int) $m[0];
    }

    return $default;
}

function parse_bool_ja_nein($v): ?string {
    if ($v === null) {
        return null;
    }

    $s = mb_strtolower(trim((string) $v), 'UTF-8');
    if ($s === '') {
        return null;
    }

    if (in_array($s, ['ja', 'j', 'yes', 'y', '1', 'true', 'wahr'], true)) {
        return 'Ja';
    }
    if (in_array($s, ['nein', 'n', 'no', '0', 'false', 'falsch'], true)) {
        return 'Nein';
    }

    return trim((string) $v);
}

function table_exists(PDO $pdo, string $table): bool {
    static $cache = [];
    if (array_key_exists($table, $cache)) {
        return $cache[$table];
    }

    $sql = 'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table';
    $st = $pdo->prepare($sql);
    $st->execute([':table' => $table]);
    $cache[$table] = ((int) $st->fetchColumn()) > 0;
    return $cache[$table];
}

function column_exists(PDO $pdo, string $table, string $column): bool {
    static $cache = [];
    $key = $table . '.' . $column;
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    $sql = 'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table AND COLUMN_NAME = :column';
    $st = $pdo->prepare($sql);
    $st->execute([
        ':table' => $table,
        ':column' => $column,
    ]);
    $cache[$key] = ((int) $st->fetchColumn()) > 0;
    return $cache[$key];
}

function resolve_lrb_column(PDO $pdo): ?string {
    foreach (['luftraumbeobachter_anwesend', 'luftraumbeobachter'] as $candidate) {
        if (column_exists($pdo, 'flugbuch_verein', $candidate)) {
            return $candidate;
        }
    }
    return null;
}

function exists_flight(PDO $pdo, string $datum, string $beginn, string $pilot): bool {
    $sql = 'SELECT 1 FROM `flugbuch_verein` WHERE `datum` = :d AND `beginn` = :b AND `pilot` = :p LIMIT 1';
    $st = $pdo->prepare($sql);
    $st->execute([
        ':d' => $datum,
        ':b' => $beginn,
        ':p' => $pilot,
    ]);
    return (bool) $st->fetchColumn();
}

function insert_flight(PDO $pdo, array $row, ?string $lrbColumn): string {
    $columns = ['datum', 'beginn', 'ende', 'pilot', 'anzahl_fluege', 'max_flughoehe'];
    $params = [':datum', ':beginn', ':ende', ':pilot', ':anzahl', ':maxhoehe'];

    if ($lrbColumn !== null) {
        $columns[] = $lrbColumn;
        $params[] = ':lrb';
    }

    $columns[] = 'erfasser';
    $params[] = ':erfasser';
    $columns[] = 'erfasst';
    $params[] = 'NOW()';

    $sql = 'INSERT INTO `flugbuch_verein` (`' . implode('`,`', $columns) . '`) VALUES (' . implode(',', $params) . ')';
    $st = $pdo->prepare($sql);
    $st->execute($row);

    return (string) $pdo->lastInsertId();
}

function resolve_erfasser_member(PDO $pdo, string $pilotName): ?array {
    static $cache = [];

    $pilotName = trim($pilotName);
    if ($pilotName === '') {
        return null;
    }

    if (array_key_exists($pilotName, $cache)) {
        return $cache[$pilotName];
    }

    if (!table_exists($pdo, 'membership_users') || !column_exists($pdo, 'membership_users', 'memberID') || !column_exists($pdo, 'membership_users', 'custom1')) {
        $cache[$pilotName] = null;
        return null;
    }

    $hasGroupId = column_exists($pdo, 'membership_users', 'groupID');

    $sql = 'SELECT memberID' . ($hasGroupId ? ', groupID' : '') . ' FROM membership_users WHERE LOWER(custom1) LIKE :name LIMIT 2';
    $st = $pdo->prepare($sql);
    $st->execute([
        ':name' => '%' . mb_strtolower($pilotName, 'UTF-8') . '%',
    ]);

    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    if (count($rows) !== 1) {
        $cache[$pilotName] = null;
        return null;
    }

    $cache[$pilotName] = [
        'memberID' => (string) $rows[0]['memberID'],
        'groupID'  => isset($rows[0]['groupID']) && $rows[0]['groupID'] !== '' ? (string) $rows[0]['groupID'] : DEFAULT_GROUP_ID,
    ];

    return $cache[$pilotName];
}

function set_record_owner(PDO $pdo, string $pkValue, string $memberID, string $groupID = DEFAULT_GROUP_ID): void {
    if ($pkValue === '' || $memberID === '') {
        return;
    }

    if (!table_exists($pdo, 'membership_userrecords')) {
        return;
    }

    $ts = time();

    $sql = 'INSERT INTO membership_userrecords (tableName, pkValue, memberID, dateAdded, dateUpdated, groupID) VALUES (:tableName, :pk, :member, :ts, :ts, :groupID)';
    $st = $pdo->prepare($sql);
    $st->execute([
        ':tableName' => 'flugbuch_verein',
        ':pk'        => $pkValue,
        ':member'    => $memberID,
        ':ts'        => $ts,
        ':groupID'   => $groupID,
    ]);
}

$raw = file_get_contents('php://input');
$payload = json_decode($raw, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Ungültiges JSON: ' . json_last_error_msg(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$entries = null;
$incomingId = null;
if (is_array($payload) && isset($payload['ID'], $payload['data']) && is_array($payload['data'])) {
    $incomingId = (string) $payload['ID'];
    $entries = $payload['data'];
}

if (!is_array($entries) || $incomingId === '') {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Ungültige Datenstruktur. Erwartet {ID:string, data:[...]}',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    enforce_id_or_init($incomingId);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'ID-Check Fehler: ' . $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

usort($entries, static function ($a, $b) {
    $aStart = entry_value((array) $a, ['startzeit'], '');
    $bStart = entry_value((array) $b, ['startzeit'], '');
    return strtotime((string) $aStart) <=> strtotime((string) $bStart);
});

try {
    $pdo = build_pdo_from_config();
    $lrbColumn = resolve_lrb_column($pdo);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'DB init Fehler: ' . $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$today = (new DateTime('now'))->format('Y-m-d');
$created = 0;
$skipped = 0;
$errors = 0;

log_event('request', [
    'remote' => $_SERVER['REMOTE_ADDR'] ?? null,
    'id' => $incomingId,
    'count' => count($entries),
    'lrb_column' => $lrbColumn,
]);

foreach ($entries as $entry) {
    if (!is_array($entry)) {
        $errors++;
        log_event('skip_invalid', ['reason' => 'entry_not_array', 'entry' => $entry]);
        continue;
    }

    $name = entry_value($entry, ['name']);
    $startZeit = entry_value($entry, ['startzeit']);
    $endZeit = entry_value($entry, ['endzeit']);

    foreach (['name' => $name, 'startzeit' => $startZeit, 'endzeit' => $endZeit] as $field => $value) {
        if ($value === null || trim((string) $value) === '') {
            $errors++;
            log_event('skip_invalid', ['missing' => $field, 'entry' => $entry]);
            continue 2;
        }
    }

    try {
        $start = dt_parts((string) $startZeit);
        $endT = dt_parts((string) $endZeit)['time'];
    } catch (Throwable $e) {
        $errors++;
        log_event('skip_invalid_datetime', ['msg' => $e->getMessage(), 'entry' => $entry]);
        continue;
    }

    if ($start['datum'] !== $today) {
        $skipped++;
        log_event('skip_not_today', ['datum' => $start['datum'], 'entry' => $entry]);
        continue;
    }

    $pilot = trim((string) $name);
    $anzahl = parse_int_mixed(entry_value($entry, ['Fluganzahl', 'fluganzahl']), 1);
    $maxh = parse_int_mixed(entry_value($entry, ['Flughöhe', 'Flughoehe', 'flughoehe', 'flughöhe', 'FlughÃ¶he']), null);
    $lrb = parse_bool_ja_nein(entry_value($entry, ['Luftraumbeobachter', 'luftraumbeobachter']));

    try {
        if (exists_flight($pdo, $start['datum'], $start['time'], $pilot)) {
            $skipped++;
            log_event('skip_exists', ['datum' => $start['datum'], 'beginn' => $start['time'], 'pilot' => $pilot]);
            continue;
        }

        $member = resolve_erfasser_member($pdo, $pilot);
        $erfasser = $member['memberID'] ?? DEFAULT_ERFASSER;

        $params = [
            ':datum' => $start['datum'],
            ':beginn' => $start['time'],
            ':ende' => $endT,
            ':pilot' => $pilot,
            ':anzahl' => $anzahl,
            ':maxhoehe' => $maxh,
            ':erfasser' => $erfasser,
        ];

        if ($lrbColumn !== null) {
            $params[':lrb'] = $lrb;
        }

        $pk = insert_flight($pdo, $params, $lrbColumn);

        if ($member !== null && !empty($member['memberID'])) {
            set_record_owner(
                $pdo,
                $pk,
                $member['memberID'],
                $member['groupID'] ?? DEFAULT_GROUP_ID
            );
        }

        $created++;
        log_event('created', [
            'datum' => $start['datum'],
            'beginn' => $start['time'],
            'pilot' => $pilot,
            'erfasser' => $erfasser,
        ]);
    } catch (Throwable $e) {
        $errors++;
        log_event('error', ['msg' => $e->getMessage(), 'pilot' => $pilot ?? null]);
        error_log('[rfidFlugbuch receiver] ' . $e->getMessage());
    }
}

echo json_encode([
    'status' => $errors ? 'partial' : 'success',
    'created' => $created,
    'skipped' => $skipped,
    'errors' => $errors,
], JSON_UNESCAPED_UNICODE);
