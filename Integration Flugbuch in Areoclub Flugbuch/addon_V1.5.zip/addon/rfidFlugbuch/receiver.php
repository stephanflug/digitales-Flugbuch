<?php
/**
 * receiver.php – RFID Flugbuch → AppGini (flugbuch_verein)
 *
 * Erwartete Payload: Objekt mit ID + Datenarray, z.B.
 * {
 *   "ID": "DEINE-DEVICE-ID",
 *   "data": [
 *     {
 *       "name": "Max Mustermann",
 *       "rfid": "660953104538",
 *       "startzeit": "2024-12-12 12:26:27",
 *       "endzeit": "2024-12-12 12:26:34",
 *       "Fluganzahl": "4",
 *       "Flughöhe": "120m",
 *       "Luftraumbeobachter": "Ja"
 *     }
 *   ]
 * }
 *
 * Logik:
 * - Nur Einträge vom HEUTIGEN Tag werden in AppGini geschrieben.
 * - Dedupe: datum + beginn + pilot
 * - DB Zugangsdaten werden aus ../../config.php geladen (AppGini).
 */

// ---- Addon Meta ----
const RFID_FLUGBUCH_ADDON_DEV = 'Ebner Stephan';
const RFID_FLUGBUCH_ADDON_VERSION = '1.5';

header('Content-Type: application/json; charset=utf-8');
header('X-Addon-Developer: ' . RFID_FLUGBUCH_ADDON_DEV);
header('X-Addon-Version: ' . RFID_FLUGBUCH_ADDON_VERSION);
date_default_timezone_set('Europe/Vienna');

// -------------------- config.php einbinden --------------------
// Wichtig: NICHT require_once – AppGini kann config.php in einem Funktions-Scope geladen haben.
// Dann wären $dbServer/... hier NICHT sichtbar. Daher require (erneut) im globalen Scope.
require __DIR__ . '/../../config.php';

function cfg_get(array $keys, $default = null) {
    // 1) Globals
    foreach ($keys as $k) {
        if (array_key_exists($k, $GLOBALS) && $GLOBALS[$k] !== null && $GLOBALS[$k] !== '') return $GLOBALS[$k];
    }
    // 2) $config array (häufig in AppGini)
    if (isset($GLOBALS['config']) && is_array($GLOBALS['config'])) {
        foreach ($keys as $k) {
            if (array_key_exists($k, $GLOBALS['config']) && $GLOBALS['config'][$k] !== null && $GLOBALS['config'][$k] !== '') return $GLOBALS['config'][$k];
        }
    }
    // 3) Konstanten
    foreach ($keys as $k) {
        if (defined($k)) {
            $v = constant($k);
            if ($v !== null && $v !== '') return $v;
        }
    }
    return $default;
}

function build_pdo_from_config(): PDO {
    // Unterstützt viele AppGini/config.php Varianten
    $host = cfg_get(['dbServer','dbHost','DB_HOST','mysql_host','APP_DB_HOST','HOST','HOSTNAME'], 'localhost');
    $user = cfg_get(['dbUsername','dbUser','DB_USER','mysql_user','APP_DB_USER','USER','USERNAME'], '');
    $pass = cfg_get(['dbPassword','dbPass','DB_PASS','mysql_password','APP_DB_PASS','PASS','PASSWORD'], '');
    $name = cfg_get(['dbDatabase','dbName','DB_NAME','mysql_db','APP_DB_NAME','DATABASE','DB_DATABASE'], '');

    // Manche config.php liefert/returnt ein Array (optional) – falls jemand include statt require nutzt.
    if (is_array($host) || is_array($user) || is_array($name)) {
        throw new RuntimeException('DB Config Werte haben falschen Typ (Array) – config.php Struktur prüfen.');
    }

    if (!$name || !$user) {
        throw new RuntimeException('DB creds missing');
    }

    $dsn = "mysql:host={$host};dbname={$name};charset=utf8mb4";
    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

function dt_parts(string $s): array {
    // Erwartet "YYYY-mm-dd HH:ii:ss" oder ISO; DateTime kann beides.
    $dt = new DateTime($s);
    return [
        'datum'  => $dt->format('Y-m-d'),
        'time'   => $dt->format('H:i:s'),
    ];
}

// -------- ID Absicherung (wie im alten Code) --------
function ids_path(): string {
    $p1 = '/opt/digitalflugbuch/data/system/ids.json';
    if (is_dir(dirname($p1))) return $p1;
    return __DIR__ . '/ids.json';
}

function safe_json_load(string $path, int $retries = 5, int $sleepMs = 50) {
    if (!file_exists($path)) return [];
    for ($i = 0; $i < $retries; $i++) {
        $fp = @fopen($path, 'r');
        if ($fp === false) { usleep($sleepMs * 1000); continue; }
        @flock($fp, LOCK_SH);
        clearstatcache(true, $path);
        $size = filesize($path);
        $raw  = $size > 0 ? fread($fp, $size) : '';
        @flock($fp, LOCK_UN);
        fclose($fp);

        if ($raw === '' || $raw === false) return [];
        $data = json_decode($raw, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($data)) return $data;

        usleep($sleepMs * 1000);
    }
    throw new RuntimeException("Konnte '$path' nicht stabil als JSON lesen: " . json_last_error_msg());
}

function safe_json_save(string $path, $data): void {
    $dir = dirname($path);
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        throw new RuntimeException("Verzeichnis '$dir' konnte nicht erstellt werden.");
    }
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        throw new RuntimeException('JSON-Encoding fehlgeschlagen: ' . json_last_error_msg());
    }
    $tmp = tempnam($dir, 'tmp_');
    if ($tmp === false) throw new RuntimeException("Tempdatei in '$dir' konnte nicht erstellt werden.");

    $fp = fopen($tmp, 'c');
    if ($fp === false) { @unlink($tmp); throw new RuntimeException("Tempdatei '$tmp' konnte nicht geöffnet werden."); }

    if (!flock($fp, LOCK_EX)) { fclose($fp); @unlink($tmp); throw new RuntimeException("Konnte Lock für '$tmp' nicht erhalten."); }
    if (fwrite($fp, $json) === false) { flock($fp, LOCK_UN); fclose($fp); @unlink($tmp); throw new RuntimeException("Fehler beim Schreiben nach '$tmp'."); }

    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    if (!rename($tmp, $path)) { @unlink($tmp); throw new RuntimeException("Konnte '$path' nicht ersetzen."); }
}

function enforce_id_or_init(string $incomingId): void {
    $path = ids_path();
    if (!file_exists($path)) {
        safe_json_save($path, ['ID' => $incomingId]);
        return;
    }

    $idData = safe_json_load($path);
    if (!isset($idData['ID']) || $idData['ID'] !== $incomingId) {
        http_response_code(403);
        echo json_encode([
            'status' => 'error',
            'message' => 'Die angegebene ID stimmt nicht mit der gespeicherten ID überein.'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

function parse_int_mixed($v, ?int $default = null): ?int {
    if ($v === null) return $default;
    if (is_int($v)) return $v;
    $s = trim((string)$v);
    if ($s === '') return $default;
    if (preg_match('/-?\d+/', $s, $m)) return (int)$m[0];
    return $default;
}

function parse_bool_ja_nein($v): ?string {
    if ($v === null) return null;
    $s = mb_strtolower(trim((string)$v));
    if ($s === '') return null;
    // speichern wir in AppGini als "Ja"/"Nein" (varchar)
    if (in_array($s, ['ja','j','yes','y','1','true','wahr'], true)) return 'Ja';
    if (in_array($s, ['nein','n','no','0','false','falsch'], true)) return 'Nein';
    // unbekannt → original zurück (falls schon Ja/Nein anders geschrieben)
    return trim((string)$v);
}

function exists_flight(PDO $pdo, string $datum, string $beginn, string $pilot): bool {
    $sql = "SELECT 1 FROM `flugbuch_verein` WHERE `datum`=:d AND `beginn`=:b AND `pilot`=:p LIMIT 1";
    $st = $pdo->prepare($sql);
    $st->execute([':d' => $datum, ':b' => $beginn, ':p' => $pilot]);
    return (bool)$st->fetchColumn();
}

function insert_flight(PDO $pdo, array $row): void {
    $sql = "INSERT INTO `flugbuch_verein`
      (`datum`,`beginn`,`ende`,`pilot`,`anzahl_fluege`,`max_flughoehe`,`luftraumbeobachter_anwesend`,`erfasser`,`erfasst`)
      VALUES
      (:datum,:beginn,:ende,:pilot,:anzahl,:maxhoehe,:lrb,:erfasser,NOW())";

    $st = $pdo->prepare($sql);
    $st->execute($row);
}

// -------------------- Input --------------------
$raw = file_get_contents('php://input');
$payload = json_decode($raw, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["status"=>"error","message"=>"Ungültiges JSON: " . json_last_error_msg()], JSON_UNESCAPED_UNICODE);
    exit;
}

// Erwartet: { ID: "...", data: [...] }
$entries = null;
$incomingId = null;
if (is_array($payload) && isset($payload['ID']) && isset($payload['data']) && is_array($payload['data'])) {
    $incomingId = (string)$payload['ID'];
    $entries = $payload['data'];
}

if (!is_array($entries) || !$incomingId) {
    http_response_code(400);
    echo json_encode([
        "status"=>"error",
        "message"=>"Ungültige Datenstruktur. Erwartet {ID:string, data:[...]}"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ID-Check (erstes Mal speichern, danach erzwingen)
try {
    enforce_id_or_init($incomingId);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(["status"=>"error","message"=>"ID-Check Fehler: " . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
}

// sortiere stabil nach startzeit
usort($entries, fn($a,$b) => strtotime($a['startzeit'] ?? '') <=> strtotime($b['startzeit'] ?? ''));

try {
    $pdo = build_pdo_from_config();
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(["status"=>"error","message"=>"DB init Fehler: " . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
}

$today = (new DateTime('now'))->format('Y-m-d');
$created = 0;
$skipped = 0;
$errors  = 0;

function receiver_log_path(): string {
    $p1 = '/opt/digitalflugbuch/data/system/receiver_appgini_debug.jsonl';
    if (is_dir(dirname($p1))) return $p1;
    return __DIR__ . '/system/receiver_appgini_debug.jsonl';
}

function log_event(string $type, array $payload): void {
    $line = json_encode([
        'ts' => date('c'),
        'type' => $type,
        'payload' => $payload,
    ], JSON_UNESCAPED_UNICODE);
    if ($line === false) return;
    $file = receiver_log_path();
    @mkdir(dirname($file), 0755, true);
    @file_put_contents($file, $line . "\n", FILE_APPEND);
}

log_event('request', [
    'remote' => $_SERVER['REMOTE_ADDR'] ?? null,
    'id' => $incomingId,
    'count' => is_array($entries) ? count($entries) : null,
]);

foreach ($entries as $entry) {
    foreach (["name","startzeit","endzeit"] as $k) {
        if (!isset($entry[$k]) || trim((string)$entry[$k]) === '') {
            $errors++;
            log_event('skip_invalid', ['missing' => $k, 'entry' => $entry]);
            continue 2;
        }
    }

    $start = dt_parts($entry['startzeit']);
    if ($start['datum'] !== $today) {
        $skipped++;
        log_event('skip_not_today', ['datum' => $start['datum'], 'entry' => $entry]);
        continue;
    }

    $endT = dt_parts($entry['endzeit'])['time'];

    // Mapping
    $pilot = trim((string)$entry['name']);
    $anzahl = parse_int_mixed($entry['Fluganzahl'] ?? $entry['fluganzahl'] ?? null, 1);
    $maxh = parse_int_mixed($entry['Flughöhe'] ?? $entry['Flughhe'] ?? $entry['Flughoehe'] ?? $entry['FlughÃ¶he'] ?? null, null);
    $lrb  = parse_bool_ja_nein($entry['Luftraumbeobachter'] ?? $entry['luftraumbeobachter'] ?? null);

    try {
        if (exists_flight($pdo, $start['datum'], $start['time'], $pilot)) {
            $skipped++;
            log_event('skip_exists', ['datum' => $start['datum'], 'beginn' => $start['time'], 'pilot' => $pilot]);
            continue;
        }

        insert_flight($pdo, [
            ':datum'    => $start['datum'],
            ':beginn'   => $start['time'],
            ':ende'     => $endT,
            ':pilot'    => $pilot,
            ':anzahl'   => $anzahl,
            ':maxhoehe' => $maxh,
            ':lrb'      => $lrb,
            ':erfasser' => 'RFID Flugbuch',
        ]);

        $created++;
        log_event('created', ['datum' => $start['datum'], 'beginn' => $start['time'], 'pilot' => $pilot]);
    } catch (Throwable $e) {
        $errors++;
        log_event('error', ['msg' => $e->getMessage()]);
        error_log('[rfidFlugbuch receiver] ' . $e->getMessage());
    }
}

echo json_encode([
    'status'  => $errors ? 'partial' : 'success',
    'created' => $created,
    'skipped' => $skipped,
    'errors'  => $errors,
], JSON_UNESCAPED_UNICODE);
