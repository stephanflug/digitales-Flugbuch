<?php
// Speicherpfad f�r die ID-Datei
$idFile = "ids.json";

// JSON-Daten aus dem HTTP-POST abrufen
$jsonData = file_get_contents("php://input");

// Stellen Sie sicher, dass die Daten im richtigen UTF-8-Format sind
$jsonData = mb_convert_encoding($jsonData, 'UTF-8', mb_detect_encoding($jsonData, 'UTF-8, ISO-8859-1', true));

// JSON in ein PHP-Array dekodieren
$data = json_decode($jsonData, true);

// �berpr�fen, ob die Daten g�ltig sind
if (!$data || !isset($data["ID"]) || !isset($data["data"])) {
    echo json_encode(["status" => "error", "message" => "Ung�ltige Daten"], JSON_UNESCAPED_UNICODE);
    exit;
}

// Wenn die ID-Datei nicht existiert, erstellen und speichern wir die ID
if (!file_exists($idFile)) {
    $initialIdData = ["ID" => $data["ID"]];
    $result = file_put_contents($idFile, json_encode($initialIdData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    if ($result === false) {
        echo json_encode(["status" => "error", "message" => "Fehler beim Erstellen von ids.json"], JSON_UNESCAPED_UNICODE);
        exit;
    }
} else {
    // ID-Datei lesen
    $idData = json_decode(file_get_contents($idFile), true);

    // Vergleiche die empfangene ID mit der gespeicherten ID
    if (!isset($idData["ID"]) || $idData["ID"] !== $data["ID"]) {
        echo json_encode(["status" => "error", "message" => "Die angegebene ID stimmt nicht mit der gespeicherten ID �berein."], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// Sortieren der empfangenen Daten nach dem "startzeit"-Feld (chronologisch)
usort($data["data"], function($a, $b) {
    return strtotime($a["startzeit"]) - strtotime($b["startzeit"]);
});

// Sicherstellen, dass das Verzeichnis f�r Flugdaten existiert
$flugdatenVerzeichnis = "flugdaten";
if (!is_dir($flugdatenVerzeichnis)) {
    if (!mkdir($flugdatenVerzeichnis, 0777, true)) {
        echo json_encode(["status" => "error", "message" => "Verzeichnis 'flugdaten' konnte nicht erstellt werden."], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// Gehe alle empfangenen Daten durch und speichere sie in der entsprechenden Monatsdatei
foreach ($data["data"] as $entry) {
    // Bestimme den Monat und Jahr basierend auf der "startzeit"
    $startDate = new DateTime($entry["startzeit"]);
    $yearMonth = $startDate->format('Y_m'); // Format: 2025_04

    // Speicherpfad f�r die Monatsdatei
    $filename = "$flugdatenVerzeichnis/flugdaten_" . $yearMonth . ".json";

    // Bestehende Datei laden oder neue vorbereiten
    $existingData = file_exists($filename) ? json_decode(file_get_contents($filename), true) : [];
    if (!is_array($existingData)) $existingData = [];

    // Doppelte Eintr�ge vermeiden
    $exists = false;
    foreach ($existingData as $existingEntry) {
        if (
            $existingEntry["rfid"] === $entry["rfid"] &&
            $existingEntry["startzeit"] === $entry["startzeit"] &&
            $existingEntry["endzeit"] === $entry["endzeit"]
        ) {
            $exists = true;
            break;
        }
    }

    if (!$exists) {
        $existingData[] = $entry;
    }

    file_put_contents($filename, json_encode($existingData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

echo json_encode(["status" => "success", "message" => "Daten gespeichert!"], JSON_UNESCAPED_UNICODE);
?>
