<?php
$users = [
    'stephan' => password_hash('geheim', PASSWORD_DEFAULT),
    'admin' => password_hash('geheim', PASSWORD_DEFAULT),
];
?>
